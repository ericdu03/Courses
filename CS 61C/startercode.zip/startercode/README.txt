Test1.txt: The mashed potatoes task list
solver.py: Generates a solution given a task list. The starter code handles input parsing, and outputs in the correct format
verifier.py: Verifies and scores a proposed solution.
questiongenerator.py: Generates a new test case. Useful if you want to test your code further.

Running any of the python scripts with no arguments will provide further information on expected input
