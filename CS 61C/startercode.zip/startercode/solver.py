#Setup
import sys
if "-v" in sys.argv:
    verbose = True
    sys.argv.remove("-v")
else:
    verbose = False
if len(sys.argv) != 3:
    print(f"Usage: {sys.argv[0]} <test case> <thread count> [-v]")
    print("Finds a solution for a given test case.")
    print("test case should be a file containing the data value")
    print("The starter code automatically parses the input file for you, and writes an answer in the appropriate format")
    print("You can save your answer by piping your output to a file (assuming you have no additional print statements)")
    print(f"ex: {sys.argv[0]} Test1.txt 2 > answer.out")
    print("An optional -v argument is included, but currently does nothing. You may want to use it as a verbose flag,")
    print("so that debugging data gets printed only when verbose is set to True.")
    exit()

#Parse input
def parsetestfile(testfile):
    data = testfile.readlines()[1:]
    result = []
    for i in data:
        element = [int(j) for j in i.strip().split(" ")]
        result.append({"TaskID":element[0], "runtime":element[1], "prerequisites":element[3:]})
    return result
testfile = open(sys.argv[1])
test = parsetestfile(testfile)
testfile.close()
threadcount = int(sys.argv[2])

#Return a list of length threadcount, where each list details what each thread does
def findsolution(test, threadcount):
    #YOUR SOLUTION HERE
    print(test)
    return [list(range(len(test)))]+[[]]*(threadcount-1)



result = findsolution(test, threadcount)
val = ""
for i in result:
    for j in i:
        val+=str(j)+","
    val=val[:-1]+";"
print(val[:-1])
